import { useEffect, useState } from 'react'
import Character from './components/Character/Character';
import './app.css'
function App() {

  const [personajes, setPersonajes] = useState()
  console.log(personajes);
  
  useEffect(() => {
    fetch('https://rickandmortyapi.com/api/character?page=1')
    .then((response) => response.json())
    .then((data) => setPersonajes(data.results))
    .catch((err) => console.error(err))
  }, [])




  return (
    <>
      <header> Nav </header>
      <main>
        {
          personajes ? 
            personajes.map( (personaje) => <Character key={personaje.id} {...personaje} />)
          : <p>Cargando...</p>
        }
      </main>
      
      
    </>
  )
}

export default App
