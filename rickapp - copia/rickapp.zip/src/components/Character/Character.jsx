import React from 'react';
import './character.css'

const Character = ({image, name, species, type, gender, status}) => {
    // const {image, name, species, type, gender, status} = personaje
    
    return (
        <div className='card'>
            <div className='card_img'>
                <img src={image} alt={name} />
            </div>
            <div className='card_data'>
                <h3>{name}</h3>
                <h3>{species}</h3>
                <h4>{type}</h4>
                <span> {gender} </span>
                <p>{status}</p>
            </div>
        </div>
    );
}

export default Character;






